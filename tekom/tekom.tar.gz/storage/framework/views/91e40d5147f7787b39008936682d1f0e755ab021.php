<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table align="center">
        <tr>    
            <td colspan="3" align="center"><img src="<?php echo e(asset("img/".Auth::user()->photo)); ?>" alt="" srcset=""></td>
        </tr>
        <tr>
            <td>Nama Lengkap</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->name); ?></td>
        </tr>
        <tr>
            <td>NIM</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->nim); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->email); ?></td>
        </tr>
        <tr>
            <td>Telephone</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->telp); ?></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->gender); ?></td>
        </tr>
        <tr>
            <td>Status</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->status); ?></td>
        </tr>
        <tr>
            <td>Instagram</td>
            <td>:</td>
            <td><a href="http://www.instagram.com/<?php echo e(Auth::user()->instagram); ?>"><?php echo e(Auth::user()->instagram); ?></a></td>
        </tr>
        <tr>
            <td>Job</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->job); ?></td>
        </tr>
        <tr>
            <td>Company</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->company); ?></td>
        </tr>
        <tr>
            <td>Kajian</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->kajian); ?></td>
        </tr>
        <tr>
            <td>Judul Tugas Akhir</td>
            <td>:</td>
            <td><?php echo e(Auth::user()->title); ?></td>
        </tr>
        <tr>
            <td>Verified</td>
            <td>:</td>
            <td>
                <?php if(Auth::user()->isVerified): ?>
                    <span class="btn btn-success">Verified</span>
                <?php else: ?>
                    <span class="btn btn-danger">Not Verified</span>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <?php if(!Auth::user()->isVerified): ?>
                <td colspan="3" align="center"><a href="<?php echo e(route("verify")); ?>" class="btn btn-success">Verify</a></td>
            <?php endif; ?>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mansky/Laravel/adminLTE/resources/views/account.blade.php ENDPATH**/ ?>