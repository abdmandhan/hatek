<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="row">
        <div class="col-md-8">
            <h2 class="text-center">Post</h2>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box box-primary"><!-- /.box -->
                        <div class="box-header with-border">
                            <div class="row">
                                <div class="col-md-1 text-center">
                                    <img src="<?php echo e(asset("img/".$post->user->photo)); ?>" alt="" srcset="" class="img-circle" height="50px" >
                                </div>
                                <div class="col-md-4">
                                    <?php echo e($post->user->name); ?> <br>
                                    <?php echo e($post->title); ?> <br>
                                    <span class="<?php if($post->category == "Event") echo "bg-warning"; elseif($post->category == "Information") echo "bg-info"; else echo "bg-danger"; ?>"><?php echo e($post->category); ?></span>
                                </div>
                            </div>   
                            <div class="box-tools pull-right">
                                <form action="post/<?php echo e($post->id); ?>" method="POST">
                                    <?php echo e($post->created_at->format('Y-m-d')); ?>

                                    <?php if($post->user_id == Auth::user()->id): ?>
                                        <a href="post/<?php echo e($post->id); ?>" class="fa fa-edit btn btn-box-tool"></a> 
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?> 
                                        <button class="btn btn-box-tool" onclick="return confirm('Are you sure?')" type="submit"><i class="fa fa-trash" ></i></button>   
                                    <?php endif; ?> 
                                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                </form>
                            </div><!-- /.box-tools -->
                        </div><!-- /.box-header -->
                        <div class="box-body" style="height: 100%;">
                            
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-11">
                                    <?php echo $post->body; ?>

                                </div>
                            </div>
                            <div class="row text-center">
                                <hr style="margin-left: 5px; margin-right: 5px; margin:5px">
                                <div class="col-md-4"><a href="<?php echo e(url("like/".$post->id)); ?>"><i class="far fa-thumbs-up"></i> <?php echo e($post->likes->count()); ?> Suka</a></div>
                                <div class="col-md-4"><a href="<?php echo e(url("comment/".$post->id)); ?>"><i class="far fa-comment-alt"></i> <?php echo e($post->comments->count()); ?> Comment</a></div>
                                <?php if($post->user_id == Auth::user()->id): ?>
                                    <form action="<?php echo e(route('post.broadcast')); ?>" method="POST" class="col-md-4" id="formShare">
                                        <input type="text" name="postId" value="<?php echo e($post->id); ?>" hidden>
                                        <input type="text" name="userId" value="<?php echo e($post->user->id); ?>" hidden>
                                        <?php echo csrf_field(); ?>

                                        <a href="javascript:;" type="submit" onclick="document.getElementById('formShare').submit();"><i class="far fa-envelope"></i> Share</a>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div><!-- /.box-body -->
                    </div><!-- /.box -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
        <div class="col-md-4">
            <div class="row">
                <div class="box box-primary box-solid">
                    <div class="box-header with-border">
                        <h3 class="box-title">Online User</h3>
                        <div class="box-tools pull-right">
                            <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                        </div><!-- /.box-tools -->
                    </div><!-- /.box-header -->
                    <div class="box-body pre-scrollable" style="height: 150px">
                        <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($friend->isOnline()): ?>
                                <a href="<?php echo e(url('friends/'.$friend->nim)); ?>"><?php echo e($friend->name); ?> '<?php echo e($friend->angkatan); ?></a>
                                <br>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->            
            </div>
            <div class="row">
                <div class="box box-primary box-solid">
                    <div class="box-header with-border">
                        <h3 class="box-title">Instagram Teknik Komputer</h3>
                        <div class="box-tools pull-right">
                            <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                        </div><!-- /.box-tools -->
                    </div><!-- /.box-header -->
                    <div class="box-body pre-scrollable" style="height: 250px">
                        <?php for($i = 0; $i < sizeof($instagrams); $i++): ?>
                            <img src="<?php echo e($instagrams[$i]->images->thumbnail->url); ?>" alt="" srcset="">
                            
                        <?php endfor; ?>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->            
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/adminLTE/resources/views/home.blade.php ENDPATH**/ ?>