<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Posts</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('post.update',$post->id)); ?>" method="post">
        <?php echo csrf_field(); ?>


        <div class="form-group has-feedback <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
            <input type="title" name="title" class="form-control" value="<?php echo e($post->title); ?>"
                   placeholder="Title">
            <span class="fa fa-paperclip form-control-feedback"></span>
            <?php if($errors->has('title')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('category') ? 'has-error' : ''); ?>">
            <select name="category" class="form-control" value="<?php echo e(old('category')); ?>">
                <option value="" disabled selected>Category</option>
                <option value="Event" <?php if($post->category == "Event"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Event</option>
                <option value="Information" <?php if($post->category == "Information"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Information</option>
                <option value="Lowongan Kerja" <?php if($post->category == "Lowongan Kerja"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Lowongan Kerja</option>
            </select>
            <span class="fa fa-bookmark form-control-feedback"></span>
            <?php if($errors->has('category')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('category')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('body') ? 'has-error' : ''); ?>">
            <textarea type="text" name="body" class="form-control" value="<?php echo e($post->body); ?>"
                   placeholder="Write Here !" rows="10"><?php echo e($post->body); ?></textarea>
            <span class="fa fa-keyboard form-control-feedback"></span>
            <?php if($errors->has('body')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('body')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <?php echo method_field('PUT'); ?>
        <button type="submit"
                class="btn btn-primary btn-block btn-flat"
        >Update</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mansky/Laravel/adminLTE/resources/views/post/edit.blade.php ENDPATH**/ ?>