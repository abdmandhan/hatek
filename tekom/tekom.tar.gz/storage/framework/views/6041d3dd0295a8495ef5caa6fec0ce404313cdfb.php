<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Posts</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e($post->title); ?> - <span class="label label-primary"><?php echo e($post->category); ?></span></h3>
                        <div class="box-tools pull-right">
                        <!-- Buttons, labels, and many other things can be placed here! -->
                        <!-- Here is a label for example -->
                        <?php if($post->user_id == Auth::user()->id): ?>
                            <form action="<?php echo e(route('post.broadcast')); ?>" method="POST">
                                <input type="text" name="postId" value="<?php echo e($post->id); ?>" hidden>
                                <input type="text" name="userId" value="<?php echo e($post->user->id); ?>" hidden>
                                <?php echo csrf_field(); ?>

                                <button type="submit" class="btn btn-danger btn-block btn-flat">Broadcast this post</button>
                            </form>
                        <?php endif; ?>
                        
                        </div><!-- /.box-tools -->
                    </div><!-- /.box-header -->
                    <div class="box-body">
                        <?php echo e($post->body); ?>

                        <br>
                    </div><!-- /.box-body -->
                    <div class="box-footer">
                        Written on <?php echo e($post->created_at->format('Y-m-d')); ?>, Posted by <?php echo e($post->user->name); ?> 
                        <?php if($post->user_id == Auth::user()->id): ?>
                            <div style="float:right;">
                                    
                                <form action="post/<?php echo e($post->id); ?>" method="POST">
                                    <a href="post/<?php echo e($post->id); ?>"><button class="btn fa fa-edit" type="button"></button></a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn fa fa-trash" onclick="return confirm('Are you sure?')"></button>
                                </form>
                            </div>
                            <?php endif; ?>
                    </div><!-- box-footer -->
                </div><!-- /.box -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mansky/Laravel/adminLTE/resources/views/post/posts.blade.php ENDPATH**/ ?>