<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Send Mail</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(url(config('adminlte.register_url', 'register'))); ?>" method="post">
        <?php echo csrf_field(); ?>


        From
        <div class="form-group has-feedback <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <input type="email" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>"
                    placeholder="<?php echo e(trans('adminlte::adminlte.email')); ?>" disabled>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        To
        <div class="form-group has-feedback <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>"
                   placeholder="<?php echo e(trans('adminlte::adminlte.email')); ?>">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <textarea name="name" class="form-control" placeholder="Message" rows="10"></textarea>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-danger btn-block btn-flat">Kirim</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mansky/Laravel/adminLTE/resources/views/sendMail.blade.php ENDPATH**/ ?>