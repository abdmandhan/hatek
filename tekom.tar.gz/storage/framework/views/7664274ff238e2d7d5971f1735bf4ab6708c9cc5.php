<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .form-group{
            margin-bottom: 0px;
        }
    </style>
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            
            <div class="col-md-2">
                <img src="<?php echo e(asset("img/".$user->photo)); ?>" alt="" srcset="" >
            </div>
            <div class="col-md-10">
                <h2 style="margin-top:0px;"><?php echo e($user->name); ?></h2>
                <h3><?php echo e($user->nim); ?></h3>
                <?php if($user->isVerified): ?>
                    <span class="btn btn-success">Verified</span>
                <?php else: ?>
                    <span class="btn btn-danger">Not Verified</span>
                <?php endif; ?>
            </div>
        </div>
        <br>
        <div class="row">

            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Biodata</h3>
                    <div class="box-tools pull-right">
                    <!-- Buttons, labels, and many other things can be placed here! -->
                    <!-- Here is a label for example -->
                    </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body form-horizontal">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Email:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->email); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Telephone:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->telp); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Gender:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->gender); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Status:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->status); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Instagram:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->instagram); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Job:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->job); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Company:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->company); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Kajian:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->kajian); ?></p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="email">Tugas Akhir:</label>
                            <div class="col-sm-10">
                                <p class="form-control-static"><?php echo e($user->title); ?></p>
                            </div>
                        </div>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/adminLTE/resources/views/friends-nim.blade.php ENDPATH**/ ?>