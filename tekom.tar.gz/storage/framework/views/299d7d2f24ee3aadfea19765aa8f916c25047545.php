<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Profile</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('account.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>


        <div class="form-group has-feedback <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <input type="email" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>"
                    placeholder="<?php echo e(trans('adminlte::adminlte.email')); ?>" disabled>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>"
                   placeholder="<?php echo e(trans('adminlte::adminlte.full_name')); ?>" <?php echo e(Auth::user()->isVerified ? "disabled" : ""); ?>>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('nim') ? 'has-error' : ''); ?>">
            <input type="text" name="nim" class="form-control" value="<?php echo e(Auth::user()->nim); ?>"
                   placeholder="NIM" <?php echo e(Auth::user()->isVerified ? "disabled" : ""); ?>>
            <span class="fa fa-address-card form-control-feedback"></span>
            <?php if($errors->has('nim')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('nim')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('telp') ? 'has-error' : ''); ?>">
            <input type="number" name="telp" class="form-control" value="<?php echo e(Auth::user()->telp); ?>"
                   placeholder="No Telphone">
            <span class="glyphicon glyphicon-earphone form-control-feedback"></span>
            <?php if($errors->has('telp')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('telp')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                <select name="gender" class="form-control" value="<?php echo e(old('gender')); ?>">
                    <option value="" disabled selected>Gender</option>
                    <option value="Male" <?php if(Auth::user()->gender == "Male"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Male</option>
                    <option value="Female" <?php if(Auth::user()->gender == "Female"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Female</option>
                </select>
                <span class="fa fa-venus-mars form-control-feedback"></span>
                <?php if($errors->has('gender')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('gender')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

        <div class="form-group has-feedback <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
            <select name="status" class="form-control" value="<?php echo e(old('status')); ?>">
                <option value="" disabled selected>Status</option>
                <option value="Mahasiswa" <?php if(Auth::user()->status == "Mahasiswa"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Mahasiswa</option>
                <option value="Alumni" <?php if(Auth::user()->status == "Alumni"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Alumni</option>
            </select>
            <span class="glyphicon glyphicon-education form-control-feedback"></span>
            <?php if($errors->has('status')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('status')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('instagram') ? 'has-error' : ''); ?>">
            <input type="text" name="instagram" class="form-control" value="<?php echo e(Auth::user()->instagram); ?>"
                   placeholder="Instagram">
            <span class="fa fa-instagram form-control-feedback"></span>
            <?php if($errors->has('instagram')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('instagram')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('job') ? 'has-error' : ''); ?>">
            <input type="text" name="job" class="form-control" value="<?php echo e(Auth::user()->job); ?>"
                   placeholder="Job">
            <span class="fa fa-briefcase form-control-feedback"></span>
            <?php if($errors->has('job')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('job')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('company') ? 'has-error' : ''); ?>">
            <input type="text" name="company" class="form-control" value="<?php echo e(Auth::user()->company); ?>"
                   placeholder="Company">
            <span class="fa fa-building form-control-feedback"></span>
            <?php if($errors->has('company')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('company')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('kajian') ? 'has-error' : ''); ?>">
            <select name="kajian" class="form-control" value="<?php echo e(Auth::user()->kajian); ?>">
                <option value="" disabled selected>Kajian</option>
                <option value="Hardware" <?php if(Auth::user()->kajian == "Hardware"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Hardware</option>
                <option value="Jaringan" <?php if(Auth::user()->kajian == "Jaringan"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Jaringan</option>
                <option value="Multimedia" <?php if(Auth::user()->kajian == "Multimedia"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Multimedia</option>
            </select>
            <span class="glyphicon glyphicon-education form-control-feedback"></span>
            <?php if($errors->has('kajian')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('kajian')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
            <textarea type="text" name="title" class="form-control" value="<?php echo e(Auth::user()->title); ?>"
                   placeholder="Judul Tugas Akhir"><?php echo e(Auth::user()->title); ?></textarea>
            <span class="fa fa-book form-control-feedback"></span>
            <?php if($errors->has('title')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <?php echo method_field('PUT'); ?>
        <button type="submit"class="btn btn-primary btn-block btn-flat">Update</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mansky/Laravel/adminLTE/resources/views/accountEdit.blade.php ENDPATH**/ ?>