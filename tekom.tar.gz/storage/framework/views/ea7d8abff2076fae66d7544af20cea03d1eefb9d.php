<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="box box-default">
            <div class="box-header with-border">
                <h3 class="box-title">Friends</h3>
                <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                </div><!-- /.box-tools -->
            </div><!-- /.box-header -->
            <div class="box-body">
                <div class="row">
                    <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="info-box">
                                <span class="info-box-icon"><img src="<?php echo e(asset('img/'.$friend->photo)); ?>" alt="" srcset="" width="80%"></span>
                                <div class="info-box-content  dropdown">
                                    <a class="info-box-text" href="<?php echo e(url('friends/'.$friend->nim)); ?>"><i class="fa fa-address-book"></i> <?php echo e($friend->name); ?></a>                                    <span class="info-box-text"><i class="fa fa-envelope"></i> <?php echo e($friend->email); ?></span>
                                    <span class="info-box-text"><i class="fa fa-graduation-cap"></i> <?php echo e($friend->angkatan); ?></span>
                                    <span class="info-box-text">
                                        <i class="fa fa-instagram"></i> 
                                        <a href="http://www.instagram.com/<?php echo e($friend->instagram); ?>" target="_blank"><?php echo e($friend->instagram); ?></a>
                                        <button class="fa fa-ellipsis-v" type="button" data-toggle="modal" style="float:right; background-color: aqua;" data-target="#myModal<?php echo e($friend->id); ?>"></button>
                                    </span>
                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal<?php echo e($friend->id); ?>" role="dialog">
                                        <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title"><?php echo e($friend->name); ?></h4>
                                            </div>
                                            <div class="modal-body">
                                                <i class="fa fa-phone"> <?php echo e($friend->telp); ?></i> <br>
                                                <i class="fa fa-briefcase"> <?php echo e($friend->job); ?></i> <br> 
                                                <i class="fa fa-building"> <?php echo e($friend->company); ?></i> <br>
                                                <i class="fa fa-graduation-cap"> <?php echo e($friend->kajian); ?></i> <br>
                                                <i class="fa fa-book"> <?php echo e($friend->title); ?></i>
                                            </div>
                                            <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>                        
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row text-center">
                    <?php echo e($friends->links()); ?>

                </div>
            </div><!-- /.box-body -->
        </div><!-- /.box -->
</div>
    
        
    
    
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/adminLTE/resources/views/friends.blade.php ENDPATH**/ ?>