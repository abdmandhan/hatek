<?php $__env->startSection('title', 'HA TEK'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Change Password</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('account.password')); ?>" method="POST">
        <?php echo csrf_field(); ?>


        <div class="form-group has-feedback <?php echo e($errors->has('oldPassword') ? 'has-error' : ''); ?>">
            <input type="password" name="oldPassword" class="form-control"
                   placeholder="Old Password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            <?php if($errors->has('oldPassword')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('oldPassword')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <hr>
        <div class="form-group has-feedback <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
            <input type="password" name="password" class="form-control"
                   placeholder="New Password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group has-feedback <?php echo e($errors->has('password_confirmation') ? 'has-error' : ''); ?>">
            <input type="password" name="password_confirmation" class="form-control"
                   placeholder="<?php echo e(trans('adminlte::adminlte.retype_password')); ?>">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            <?php if($errors->has('password_confirmation')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <?php echo method_field('PUT'); ?>
        <button type="submit"class="btn btn-danger btn-block btn-flat">Change Password</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mansky/Laravel/adminLTE/resources/views/account/accountPassword.blade.php ENDPATH**/ ?>